package StudentRecordmanage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DeleteStudent {

	public static void main(String[] args) {
		String url = "jdbc:mysql://localhost:3306/student_manager";
		String user = "root";
		String password="YOUR_MYSQL_PASSWORD";
		String sql = "DELETE FROM students WHERE Id = ?";
		try 
		{
		 Connection connect=DriverManager.getConnection(url, user, password);
		
		 PreparedStatement pstmt = connect.prepareStatement(sql);	
		  
		 
		 pstmt.setInt(1, 1);
		 int rowsaffected = pstmt.executeUpdate();
		 
		 System.out.println("deleted Successfully");
		
		 
		pstmt.close();
		connect.close();
		
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		
	}

}
