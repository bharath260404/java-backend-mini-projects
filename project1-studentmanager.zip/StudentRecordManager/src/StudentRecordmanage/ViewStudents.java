package StudentRecordmanage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ViewStudents {
	
  
  public static void main(String[] args) {
 
	  
	  String url = "jdbc:mysql://localhost:3306/student_manager";
	  String user="root";
	  String password="YOUR_MYSQL_PASSWORD";
	  String query = "SELECT * FROM students";
  try 
  {
	  Connection connect=DriverManager.getConnection(url, user, password);
	  
	  PreparedStatement pstmt =connect.prepareStatement(query);
	  
	  ResultSet rs = pstmt.executeQuery();
	  
	  while(rs.next()) {
		  System.out.println(rs.getInt("Id") + " " + rs.getString("Name") + "  "+ rs.getString("Email") + " "+ rs.getInt("age"));
	  } 
	  
	  rs.close();
	  pstmt.close();
	  connect.close();
	  
	  
  	  
  }
  catch(SQLException e){
	  e.printStackTrace();
  }
  }

}
