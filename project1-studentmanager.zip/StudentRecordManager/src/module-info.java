/**
 * 
 */
/**
 * 
 */
module StudentRecordManager {
	requires java.sql;
}