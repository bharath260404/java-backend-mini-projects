package StudentRecordmanage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Studentmanager {

	public static void main(String[] args) {
		String url = "jdbc:mysql://localhost:3306/student_manager";
		String user="root";
		String password="YOUR_MYSQL_PASSWORD";
		
		
		Scanner sc = new Scanner(System.in);
		try {
		Connection connect=DriverManager.getConnection(url, user, password);
		PreparedStatement pstmt = null;
		int choice = 0;
       while(choice!=5) {
		System.out.println("===== STUDENT RECORD MANAGER =====");
		System.out.println("1. Add Student");
		System.out.println("2. View Students");
		System.out.println("3. Update Student Email");
		System.out.println("4. Delete Student");
		System.out.println("5. Exit");

		System.out.print("Enter your choice : ");
		
	         choice = sc.nextInt();

		switch (choice) {
		    case 1:
		    	sc.nextLine();
		    	System.out.print("Enter Student Id: ");
		    	int id=sc.nextInt();
		    	sc.nextLine();
		        System.out.print("Enter Student Name: ");
		       String name =  sc.nextLine();
		        System.out.print("Enter Student Email: ");
		       String Email =  sc.nextLine();
		        System.out.print("Enter Student Age: ");
		        int age = sc.nextInt();
		        String sql1 =
		        	    "INSERT INTO students (id, Name, Email, age) VALUES (?, ?, ?, ?)";
		        pstmt = connect.prepareStatement(sql1);
		        pstmt.setInt(1, 1);
		        pstmt.setString(2, "superman");
		        pstmt.setString(3, "superman@gmail.com");
		        pstmt.setInt(4,  33);
                
		        
		        //data process
		       int RowsAffected =  pstmt.executeUpdate();
		       
		       System.out.println(RowsAffected+ " Student Added Successfully");
		        pstmt.close();
		        break;
		    case 2:
		    	 String sql2 = "SELECT * FROM students";

		    	    PreparedStatement ps2 = connect.prepareStatement(sql2);

		    	    ResultSet rs = ps2.executeQuery();

		    	    while (rs.next()) {
		    	        System.out.println(
		    	            rs.getInt("Id") + " | " +
		    	            rs.getString("Name") + " | " +
		    	            rs.getString("Email") + " | " +
		    	            rs.getInt("age")
		    	        );
		    	    }

		    	    rs.close();
		    	    ps2.close();
		        break;
		        
		    case 3:
		    	sc.nextLine();
		    	System.out.print("Enter Student Id: ");
		    	id = sc.nextInt();
		    	sc.nextLine();
		    	
		    	System.out.print("Enter new Email: ");
		    	String newEmail=sc.nextLine();
		    	String sql3= " UPDATE students SET Email = ? WHERE Id = ?";
		    	PreparedStatement ps3= connect.prepareStatement(sql3);
		    	ps3.setString(1, newEmail);
		    	ps3.setInt(2, 1);
		    	int updated  = ps3.executeUpdate();
		    	if (updated > 0) {
		            System.out.println("Student email updated successfully!");
		        } else {
		            System.out.println("Student ID not found.");
		        }

		        ps3.close();
		    	
		        break;
		        
		    case 4:
		        System.out.println("enter id to delete: ");
		        int deleteid = sc.nextInt();
		        String sql4= " DELETE FROM students WHERE Id=?";
		        PreparedStatement ps4 = connect.prepareStatement(sql4);
		        ps4.setInt(1, deleteid);
		        int deleted = ps4.executeUpdate();
		        if(deleted>0) {
		        	System.out.println("deleted successfully");
		        }
		        else {
		          System.out.println("Id not found");
		        }

		        ps4.close();
		        break;
		    case 5:
		        System.out.println("Exitinggg....");
		        break;
		    default:
		        System.out.println("Invalid choice");
		}
       }
       sc.close();
		
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}

}
