package StudentRecordmanage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UpdateStudent {

	public static void main(String[] args) {
		String url = "jdbc:mysql://localhost:3306/student_manager";
		String user = "root";
		String password="YOUR_MYSQL_PASSWORD";
		String sql = "UPDATE students SET Email=? WHERE Id = ?";
		try 
		{
		 Connection connect=DriverManager.getConnection(url, user, password);
		
		 PreparedStatement pstmt = connect.prepareStatement(sql);	
		  
		 pstmt.setString(1, "batman2@gmail.com");
		 pstmt.setInt(2, 1);
		 int rowsaffected = pstmt.executeUpdate();
		 
		 System.out.println("Updated Successfully");
		
		
		
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		
	}

}
