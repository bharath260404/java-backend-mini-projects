package StudentRecordmanage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class DBConnection {

	public static void main(String[] args) {
   
		String url = "jdbc:mysql://localhost:3306/student_manager";
		String user="root";
		String password="YOUR_MYSQL_PASSWORD";
		String sql= "INSERT INTO students (Id, Name, Email, age)" + "VALUES (?, ? ,?, ?)" ;
		
		try
		{
			
			//Establishing connection to db
			Connection connect=DriverManager.getConnection(url, user, password);
		    System.out.println("Database Connected Successfully");
			
		    //Creating statement object
		        PreparedStatement pstmt = connect.prepareStatement(sql);
		        
		        
		        //performing db operation
		        pstmt.setInt(1,  1);
		        pstmt.setString(2, "Batman");
		        pstmt.setString(3, "batman@gmail.com");
		        pstmt.setInt(4,  34);
                
		        
		        //data process
		       int RowsAffected =  pstmt.executeUpdate();
		       
		       System.out.println(RowsAffected);
		        
		       
		       //closing the connection
		     pstmt.close();
			connect.close();
			
			
			
		} catch(SQLException e)
		{
			e.printStackTrace();
		}
		
	}

}
